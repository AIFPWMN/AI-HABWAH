document.getElementById("user-input").addEventListener("keyup", function(event) {
    if (event.key === "Enter") {
        sendMessage();
    }
});

// متغيرات لمس الاعداد الافتراضية
let startY = 0;

document.getElementById("message-box").addEventListener("touchstart", startTouch, false);
document.getElementById("message-box").addEventListener("touchmove", moveTouch, false);

function startTouch(e) {
    const firstTouch = e.touches[0];
    startY = firstTouch.clientY;
}

function moveTouch(e) {
    if (!startY) {
        return;
    }

    const touch = e.touches[0];
    const distanceY = touch.clientY - startY;

    if (distanceY > 0) {
        e.preventDefault();
        document.querySelector(".chat-container").style.height = "calc(100vh - " + (100 - distanceY) + "px)";
    }
}

// فتح وإغلاق النوافذ العائمة
function openAboutUsPopup() {
    document.getElementById("about-us-popup").style.display = "flex";
}

function closeAboutUsPopup() {
    document.getElementById("about-us-popup").style.display = "none";
}

function openContactPopup() {
    document.getElementById("contact-popup").style.display = "flex";
}

function closeContactPopup() {
    document.getElementById("contact-popup").style.display = "none";
}

// دالة لإرسال الرسائل والتعامل مع OpenAI API
async function sendMessage() {
    const userInput = document.getElementById("user-input").value;
    const messageBox = document.getElementById("message-box");
    const model = document.getElementById("model-select").value;

    if (userInput.trim() === "") {
        return;
    }

    // إضافة رسالة المستخدم إلى صندوق الدردشة
    const userMessageElement = document.createElement("div");
    userMessageElement.classList.add("message", "user-message");
    userMessageElement.innerText = userInput;
    messageBox.appendChild(userMessageElement);

    // تنظيف حقل الإدخال
    document.getElementById("user-input").value = "";

    // التمرير إلى الأسفل تلقائيًا
    messageBox.scrollTop = messageBox.scrollHeight;

    // استدعاء OpenAI API للحصول على استجابة
    try {
        const response = await fetch('https://api.openai.com/v1/engines/' + model + '/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer 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' // استبدل YOUR_API_KEY بمفتاح API الخاص بك
            },
            body: JSON.stringify({
                prompt: userInput,
                max_tokens: 150
            })
        });

        const data = await response.json();
        const aiMessage = data.choices[0].text.trim();
        const aiMessageElement = document.createElement("div");
        aiMessageElement.classList.add("message", "ai-message");
        aiMessageElement.innerText = aiMessage;
        messageBox.appendChild(aiMessageElement);

        // التمرير إلى الأسفل تلقائيًا
        messageBox.scrollTop = messageBox.scrollHeight;
    } catch (error) {
        console.error('Error:', error);
        const aiMessageElement = document.createElement("div");
        aiMessageElement.classList.add("message", "ai-message");
        aiMessageElement.innerText = "حدث خطأ في الاتصال بالخادم. حاول مرة أخرى.";
        messageBox.appendChild(aiMessageElement);

        // التمرير إلى الأسفل تلقائيًا
        messageBox.scrollTop = messageBox.scrollHeight;
    }
}
